/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;


public class Perfume extends Product {
    
     //Two types of Perfume   

    public enum PerfumeType { 

        ISFORNIGHT, ISFORDAY; 

    } 

     

    //Size of perfume 100ml AND 250ml 

    public enum PerfumeSize { 

        SIZE_100ML, SIZE_250ML; 

    } 

 

    private PerfumeType type; 

    private PerfumeSize size; 

 

    public Perfume(String name, String id, double price, int stock, PerfumeType type, PerfumeSize size) { 

        super(name, id, price, stock); 

        this.type = determinePerfumeType(name);  

        this.size = size; 

        productsList.add(this); 

    } 

 

    private PerfumeType determinePerfumeType(String name) { 

        if (name.toUpperCase().equals("ISFORNIGHT")) { 

            return PerfumeType.ISFORNIGHT; 

        }  

        else if (name.toUpperCase().equals("ISFORDAY")) { 

            return PerfumeType.ISFORDAY; 

        }  

        else { 

            // Default to SUNSET if the name doesn't contain either 

            return PerfumeType.ISFORDAY; 

        } 

    } 

 

    //Print perfume product  

    public static void printPerfume() { 

        System.out.println("Perfumes List: "); 

        for (Product product : productsList) { 

            if (product instanceof Perfume) { 

                System.out.println(product.toString()); 

            } 

        } 

    } 

 

    @Override  

    public String toString() { 

         return super.toString() + ", Type: "+this.type+", Size: " + this.size + "ml"; 

    } 

} 