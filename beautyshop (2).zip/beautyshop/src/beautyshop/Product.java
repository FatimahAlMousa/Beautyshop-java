/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;
import java.util.*;


public class Product {    
    protected String itemName; 

    protected String itemId; 

    protected double price; 

    protected int stock; 

    protected static ArrayList<Product> productsList = new ArrayList<>(); 

    

    public Product(String name, String id, double price, int stock) {  

        this.itemName = name; 

        this.itemId = id; 

        this.price = price; 

        this.stock = stock; 

    } 

 

    public String getItemName() {  

        return itemName; 

    } 

    public void setItemName(String itemName) { 

        this.itemName = itemName; 

    } 

 

    public String getItemId() { 

        return itemId; 

    } 

    public void setItemId(String itemId) {  

        this.itemId = itemId; 

    } 

     

    public double getPrice() { 

        return price; 

    } 

    public void setPrice(double price) { 

        this.price = price; 

    } 

 

    public int getStock() { 

        return stock; 

    } 

    public void setStock(int stock) { 

        this.stock = stock; 

    } 

 

    public static void checkAvailability(String id) { 

        Product foundProduct = search(id); 

 

        if (foundProduct != null) { 

            boolean isAvailable = checkAvailability(foundProduct); 

            if (isAvailable) { 

                System.out.println("Product is available, Stock: " + foundProduct.getStock()); 

            } else { 

                System.out.println("Product is out of stock."); 

            } 

        } else { 

            System.out.println("Product not found."); 

        } 

    } 

 

    public static boolean checkAvailability(Product product) { 

        if( product.getStock() > 0) 

            return true; 

        else  

            return false; 

    } 

 

    //Search for specific product using ID 

    public static Product search(String id) { 

        for (Product product : productsList) { 

            if (product.getItemId().equals(id)) { 

                return product; 

            } 

        } 

        System.out.println("No matching products found."); 

        return null; 

    } 

 

    // To print all product   

    public static void displayAllProducts() {  

        System.out.println("All Products List: "); 

        for (Product product : productsList) { 

            System.out.println(product.toString()); 

        } 

    } 

  

    @Override 

    public String toString() { 

        return "Item Name: " + itemName + ", Item ID: " + itemId + ", Price: " + price + ", Stock: "+ stock; 

    } 

} 