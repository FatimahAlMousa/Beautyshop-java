/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package beautyshop;

import java.util.*;


public class Cart {
static Scanner input = new Scanner(System.in);  

   public static ArrayList<Product> clientOrder = new ArrayList<>();  

 

   public static void addOrder() {  

        System.out.print("Enter item ID you want to add: ");  

        try{  

        String idofItem = input.next();    

        for (Product product : Product.productsList)  

            if (product.getItemId().equals(idofItem.toUpperCase())){  

                if (Product.checkAvailability(product)) {  

                    clientOrder.add(product);  

                    System.out.println("Item added successfully to your order");  

                }  

                else {  

                    System.out.println("Item is out of stock");  

                }  

                return;  

            }  

            System.out.println("No product found with the given ID");  

        }  

        catch (Exception e) {  

 

            System.err.println("Please enter valid ID ");  

 

            input.nextLine();             

        }      

    }  

 

    //Delete specific order  

    public static void deleteOrder(String id) {   

        for (int i=0 ; i<clientOrder.size(); i++) {  

            if (clientOrder.get(i).getItemId().equals(id.toUpperCase())) {  

                clientOrder.remove(i);  

                System.out.println("Item removed successfully!\n" );  

                return;  

            }  

        }  

        System.out.println("Theres no item with this id."); 

    }  

 

    //Delete whole order   

    public static void deleteOrder() {  

        clientOrder.clear();  

        System.out.println("Order deleted successfully");  

    }  

 

    public static boolean canDeliver(Customer customer) {  

        String[] validLocations = {"DAMMAM", "ALKHOBAR", "ALDHAHRAN"};  

        for (String location : validLocations) {  

            if (customer.getAddress().equalsIgnoreCase(location)) {  

                return true;  

            }  

        }  

        return false;  

    }  

 

    protected static void decrementStock() {  

        for (Product product : clientOrder) {  

            if (product.getStock() > 0) {  

                product.setStock(product.getStock() - 1);  

            }  

        }  

    } 

} 

 