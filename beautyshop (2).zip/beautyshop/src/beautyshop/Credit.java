/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;


public class Credit extends Payment {
private String cardName; 

    private String expDate; 

    private String cardNum; 

 

    public Credit(String cardName, String expDate, String cardNum) throws IllegalArgumentException { 

        if (!isValidCardholder(cardName)) { 

            throw new IllegalArgumentException("Invalid cardholder name. Please enter a valid name."); 

        } 

 

        if (!isValidCardNumber(cardNum)) { 

            throw new IllegalArgumentException("Invalid card number. Please enter a valid 8-digit number."); 

        } 

 

        if (!isValidExpDate(expDate)) { 

            throw new IllegalArgumentException("Invalid expiration date. Please enter a valid date in MM/YY format."); 

        } 

 

        this.cardName = cardName; 

        this.expDate = expDate; 

        this.cardNum = cardNum; 

    } 

 

    private boolean isValidCardholder(String cardholder) { 

        return cardholder != null && !cardholder.isEmpty(); 

    } 

     

    private boolean isValidCardNumber(String cardNumber) { 

        return cardNumber != null && cardNumber.matches("\\d{8}");  // 8 digits 

    } 

 

    private boolean isValidExpDate(String expDate) { 

        return expDate != null && expDate.matches("\\d{2}/\\d{2}");  // MM/YY 

    } 

 

    protected void checkout(Customer customer) { 

        try { 

            System.out.println("Card Holder: " + cardName); 

            System.out.println("Card Number: " + cardNum); 

            System.out.println("Expiry Date: " + expDate); 

            System.out.println("Credit Checkout Successful!"); 

            System.out.println("Customer: " + customer.getUserName()); 

            System.out.println("Delivery Address: " + customer.getAddress()); 

            calculateTotalPrice(Cart.clientOrder); 

            System.out.println("Total Amount: " + totalBill()); 

 

             

            System.out.println("Credit card payment completed. Thank you!!"); 

 

            // Clear the clientOrder after successful checkout 

            Cart.clientOrder.clear(); 

        }  

        catch (Exception e) { 

            System.out.println("An error occurred during credit card checkout. Please try again or choose another payment method."); 

        } 

    } 

} 