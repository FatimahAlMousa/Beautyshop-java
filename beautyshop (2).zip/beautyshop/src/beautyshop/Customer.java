/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;

import java.util.ArrayList;

public class Customer extends User{
private String address;  

    private int numOfOrder;  

    protected static ArrayList<Customer> customerList = new ArrayList<>();  

 

    public Customer(String username, String id, String contactnum, String address){  

        super(username, id, contactnum);  

        this.address = address;  

        this.numOfOrder = 0;  

        customerList.add(this);  

    }  

 

    public void setAddress(String address) {  

        this.address = address;  

    }  

 

    public String getAddress() {  

        return address;  

    }  

 

    public int getNumOfOrder() {  

        return numOfOrder;  

    }  

 

    public void incrementNumOfOrder() {  

        numOfOrder++;  

    }  

 

    //print the customer order    

    public static void printOrder () {  

        if (Cart.clientOrder.isEmpty()) {  

            System.out.println("There is no item in your order\n");  

        }   

        else {  

            for (int i=0; i< Cart.clientOrder.size(); i++)   

                System.out.println(Cart.clientOrder.get(i));  

        }  

    }   

 

    public static Customer search(String customerId) { 

        for (Customer customer : customerList) { 

            if (customer.getId().equals(customerId)) { 

                return customer; // Found the customer 

            } 

        } 

        return null; // Customer not found 

    }  

} 

