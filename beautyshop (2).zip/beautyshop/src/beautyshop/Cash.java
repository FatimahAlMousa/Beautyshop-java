/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;

import static beautyshop.Cart.clientOrder;
import java.util.ArrayList;


/**
 *
 * @author danaa
 */

public class Cash extends Payment {
     protected final int CASH_PAY = 15; 

 

    protected void checkout(Customer customer) { 

        System.out.println("Cash Checkout Successful!"); 

        System.out.println("Customer: " + customer.getUserName()); 

        System.out.println("Delivery Address: " + customer.getAddress()); 

        System.out.println("There is cash payment fee "+ CASH_PAY); 

        double totalAmount= totalBill()+CASH_PAY; 

        System.out.println("Total Amount (including cash payment fee): " + totalAmount); 

 

      

        System.out.println("Cash payment completed. Thank you!"); 

 

        // Clear the clientOrder after successful checkout 

        Cart.clientOrder.clear(); 

    } 

} 