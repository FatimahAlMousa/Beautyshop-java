/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;

import java.util.*;


public class Makeup extends Product {
//Three shades avilable Light, Medium, Dark 

    public enum MakeupShade { 

        LIGHT, MEDIUM, DARK; 

    } 

    private MakeupShade shade; 

 

    public Makeup(String itemName, String itemId, double price, int stock, MakeupShade shade) { 

        super(itemName, itemId, price, stock); 

        this.shade = shade; 

        productsList.add(this); 

    } 

 

    public MakeupShade getShade() { 

        return this.shade; 

    } 

 

    public void setShade(MakeupShade shade) { 

        this.shade = shade; 

    } 

 

    //Print makeup product  

    public static void printMakeup() { 

        for(int i=0 ; i<productsList.size() ; i++) 

            if(productsList.get(i) instanceof Makeup) 

                System.out.println(productsList.get(i)); 

    } 

 

    @Override  

    public String toString() { 

        return super.toString() + ", Shade: " + this.shade; 

    } 

} 