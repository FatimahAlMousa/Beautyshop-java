/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;
import static beautyshop.Cart.input;
import java.util.*;
/**
 *
 * @author danaa
 */
public class Menu {
    public static boolean checkEmployee(int userInput) { 

        if (userInput == 2) { 

            Scanner scanner = new Scanner(System.in); 

 

            System.out.println("Enter the Password to access employee system:"); 

            String enteredPassword = scanner.next(); 

 

            if (Employee.validateEmployeePassword(enteredPassword)) { 

                System.out.println("Password correct. Access granted"); 

                return true; 

            } else { 

                System.out.println("Incorrect password! Access denied"); 

                return false; 

            } 

        } else { 

            return false; 

        } 

    } 

 

    public static void userStateMenu() {  

 

        System.out.println("Are you a customer or an employee?");  

 

        System.out.println("0. Exit");  

 

        System.out.println("1. Customer");  

 

        System.out.println("2. Employee");  

 

        System.out.print("Enter your choice: ");  

 

    }  

 

  

 

    public static void displayEmployeeMenu() {  

 

        System.out.println("\nEmployee Menu:");  

 

        System.out.println("1. Add employee");  

 

        System.out.println("2. Update employee");  

 

        System.out.println("3. Delete employee");  

 

        System.out.println("4. Add new makeup item");  

 

        System.out.println("5. Update item price");  

 

        System.out.println("6. Delete item");  

 

        System.out.println("7. Add item stock");  

 

        System.out.println("8. Display all products");  

 

        System.out.println("9. Print employee list"); 

         

        System.out.println("10. Exit"); 

  

 

        System.out.print("Enter your choice: ");  

 

    }  

 

  

 

    public static void displayCustomerMenu() {  

 

        System.out.println("\nCustomer Menu:");   

 

        System.out.println("1. Print menu of products");  

 

        System.out.println("2. Add to your order");  

 

        System.out.println("3. Delete item in your order");  

 

        System.out.println("4. Delete all orders");  

 

        System.out.println("5. Print your order"); 

         

        System.out.println("6. View total bill"); 

         

        System.out.println("7. Checkout and make payment");  

 

        System.out.println("8. Exit");  

         

        System.out.print("Enter your choice: ");  

 

    } 

} 