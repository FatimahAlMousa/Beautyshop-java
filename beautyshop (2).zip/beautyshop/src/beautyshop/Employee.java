/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;
 
import java.util.*;

 
public class Employee extends User {
    protected static ArrayList<Employee>empList = new ArrayList<>(); 

    private int age;  

    private static final String EMPLOYEE_PASSWORD = "EmployeePassword22";  

     

    public Employee(String empName, String empId, int age, String contNum) { 

        super(empName, empId, contNum); 

        this.age = age; 

        empList.add(this); 

    }     

     

    public int getAge() { 

        return age; 

    } 

    public void setAge(int age) { 

        this.age = age; 

    } 

 

    public static boolean validateEmployeePassword(String enteredPassword) { 

        return EMPLOYEE_PASSWORD.equals(enteredPassword); 

    } 

 

    protected static boolean isEmployeeId(String id) { 

        for (Employee employee : empList) { 

            if (employee.getId().equals(id)) { 

                return true; 

            } 

        } 

        return false; 

    } 

 

    public static void updateEmp(String empName, String empId, int age, String contNum) { 

        for (Employee employee : empList) { 

            if (employee.getId().equals(empId)) { 

                employee.setUserName(empName); 

                employee.setAge(age); 

                employee.setContactNum(contNum); 

                System.out.println("Employee information updated successfully!"); 

                return; 

            } 

        } 

        System.out.println("No employee matching this id"); 

    } 

 

    public static void deleteEmp(String empId) { 

        for(Employee employee : empList) { 

            if(employee.getId().equals(empId)) {  

                empList.remove(employee); 

                System.out.println("Employee information deleted successfully!"); 

                return; 

            } 

        } 

        System.out.println("There is no employee with this id"); 

    } 

     

    public static void addMakeup(String productName, String productId, double price, int stock, Makeup.MakeupShade shade) { 

        new Makeup(productName, productId, price, stock, shade); 

        System.out.println("Makeup product added successfully!"); 

    } 

 

    public static void addPerfume(String productName, String productId, double price, int stock, Perfume.PerfumeType type, Perfume.PerfumeSize size) { 

        new Perfume(productName, productId, price, stock, type, size); 

        System.out.println("Perfume product added successfully!"); 

    }  

 

    public static void updateItemPrice(String itemId, double newPrice) { 

        Product foundProduct = Product.search(itemId); 

 

        if (foundProduct != null) { 

            foundProduct.setPrice(newPrice); 

            System.out.println("Product price updated successfully!"); 

        }  

        else { 

            System.out.println("No product matching this ID"); 

        } 

    }  

 

    public static void deleteItem(String itemId) { 

        Product foundProduct = Product.search(itemId); 

 

        if (foundProduct != null) { 

            Product.productsList.remove(foundProduct); 

            System.out.println("Product deleted successfully!"); 

        }  

        else { 

            System.out.println("No product matching this ID"); 

        } 

    } 

 

    public static void addStock(String itemId, int quantity) { 

        Product foundProduct = Product.search(itemId); 

 

        if (foundProduct != null) { 

            foundProduct.setStock(foundProduct.getStock() + quantity); 

            System.out.println("Stock added successfully!"); 

        } else { 

            System.out.println("No product matching this ID"); 

        } 

    } 

 

    public static void printEmp() { 

        System.out.println("Employee List:"); 

        for (Employee employee : empList) { 

            System.out.println(employee.toString()); 

        } 

    } 

 

    @Override 

    public String toString() { 

        return "Employee Name: " + getUserName() + ", ID: " + getId() + ", Age: " + age + ", Contact: " + getContactNum(); 

    } 

} 