/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package beautyshop;

import java.util.*;

import static beautyshop.Cart.input;

 

public class Beautyshop {
   static Scanner input = new Scanner(System.in);  

    static Product perfume; 

    static Product perfume2; 

    static Product perfume3; 

    static Product perfume4; 

    static Product makeup; 

    static Product makeup2; 

    static Product makeup3; 

    static Product makeup4; 

    static Product makeup5; 

    static Product makeup6; 

 

    public static void main(String[] args) { 

 

        // Create some sample products  

        perfume=new Perfume("PERFUME: SUNRISE", "P001", 50.0, 10, Perfume.PerfumeType.ISFORDAY, Perfume.PerfumeSize.SIZE_100ML);  

        perfume2 = new Perfume("PERFUME: SUNSET", "P002", 50.0, 10, Perfume.PerfumeType.ISFORNIGHT, Perfume.PerfumeSize.SIZE_100ML);  

        perfume3= new Perfume("PERFUME: SUNRISE", "P003", 50.0, 10, Perfume.PerfumeType.ISFORDAY, Perfume.PerfumeSize.SIZE_250ML);  

        perfume4= new Perfume("PERFUME: SUNSET", "P004", 50.0, 10, Perfume.PerfumeType.ISFORNIGHT, Perfume.PerfumeSize.SIZE_250ML); 

        makeup = new Makeup("lip gloss", "M001", 20.0, 15, Makeup.MakeupShade.LIGHT);  

        makeup2 = new Makeup("lip gloss", "M002", 20.0, 15, Makeup.MakeupShade.DARK);  

        makeup3 = new Makeup("Blush", "M003", 20.0, 15, Makeup.MakeupShade.LIGHT);  

        makeup4 = new Makeup("Blush", "M004", 20.0, 15, Makeup.MakeupShade.DARK);  

        makeup5 = new Makeup("Blush", "M005", 20.0, 15, Makeup.MakeupShade.MEDIUM);  

        makeup6 = new Makeup("Lip gloss", "M006", 20.0, 15, Makeup.MakeupShade.MEDIUM);  

      

      

        // Create an employee  

        Employee employee = new Employee("Dana", "E22", 25, "05648932019");  

        Employee employee1 = new Employee("Sara", "E23", 25, "056869532019"); 

        Employee employee2 = new Employee("Fai", "E24", 25, "05648937629"); 

        Employee employee3 = new Employee("Fatimah", "E25", 25, "05120532019"); 

        Employee employee4 = new Employee("Shoug", "E26", 25, "05648933339"); 

        Employee employee5 = new Employee("Rhaghad", "E27", 25, "0512345678"); 

        Cart cart=new Cart(); 

 

         

        // Create a customer ALDHAHRAN 

        Customer customer1 = new Customer("Riham", "2222", "0536908372", "DAMMAM");  

        Customer customer2 = new Customer("Ahmed", "2862", "0537892017", "ALKHOBAR"); 

        Customer customer3 = new Customer("Mohammed", "7883", "0564789317", "ALDHAHRAN"); 

        Customer customer4 = new Customer("Sara", "2051", "0573892635", "ALKHOBAR"); 

  

        int userChoice; 

        do { 

            try { 

                Menu.userStateMenu(); 

                userChoice = input.nextInt(); 

 

                switch (userChoice) { 

                    case 0: 

                        break; 

                    case 1: 

                        customerSystem(); 

                        break; 

                    case 2: 

                        if (Menu.checkEmployee(userChoice)) { 

                            employeeSystem(); 

                        } 

                        break; 

                    default: 

                        System.out.println("Invalid input!"); 

                        break; 

                } 

            } catch (InputMismatchException e) { 

                System.out.println("Invalid choice! Please enter a number."); 

                input.nextLine(); // Clear the invalid choice 

                userChoice = -1; // Set to an invalid value to continue the loop 

            } 

        } while (userChoice != 0); 

    } 

  

     

    static void customerSystem() { 

    Payment payment = new Payment(); 

    Customer customer = null; 

 

    // Check if the customer already has an account 

    System.out.print("Enter customer ID: "); 

    String customerId = input.next(); 

    customer = Customer.search(customerId); 

 

    if (customer != null) { 

        System.out.println("Welcome back, " + customer.getUserName() + "!"); 

    } else { 

        // Create customer account 

        System.out.print("Name: "); 

        String name = input.next(); 

        System.out.print("Contact Number: "); 

        String contactNum = input.next(); 

        System.out.print("Address: "); 

        String address = input.next().toUpperCase(); 

 

        customer = new Customer(name, customerId, contactNum, address); 

        System.out.println("Customer account successfully created!"); 

    } 

 

    int choice; 

    do { 

        Menu.displayCustomerMenu(); 

        try { 

            choice = input.nextInt(); 

 

            switch (choice) { 

                case 1: 

                    // Print menu of products 

                    Product.displayAllProducts(); 

                    break; 

                case 2: 

                    // Add to your order 

                    Cart.addOrder(); 

                    break; 

                case 3: 

                    // Delete an item from your cart 

                    System.out.print("Enter item ID you want to delete: "); 

                    String itemId = input.next(); 

                    Cart.deleteOrder(itemId); 

                    break; 

                case 4: 

                    // Delete the whole order 

                    Cart.deleteOrder(); 

                    break; 

                case 5: 

                    // Print your order 

                    Customer.printOrder(); 

                    break; 

                case 6: 

                    // View total bill 

                    payment.totalBill(); 

                    break; 

                case 7: 

                    // Checkout and make payment 

                    if (Cart.clientOrder.isEmpty()) { 

                        System.out.println("You haven't added any items to your order. Unable to proceed to checkout."); 

                        break; 

                    } 

                    customer.printOrder(); 

                    payment.totalBill(); 

  

                    // Ask for payment method 

                    int paymentChoice; 

                    do { 

                        System.out.println("Select payment method:"); 

                        System.out.println("1. Cash"); 

                        System.out.println("2. Credit"); 

                        System.out.print("Enter your choice: "); 

                        try { 

                            paymentChoice = input.nextInt(); 

                            if (paymentChoice < 1 || paymentChoice > 2) { 

                                System.out.println("Invalid choice. Please enter 1 for Cash or 2 for Credit."); 

                            } 

                        } catch (InputMismatchException e) { 

                            System.out.println("Invalid input. Please enter a number."); 

                            input.nextLine(); // Clear the invalid input 

                            paymentChoice = -1; // Set to an invalid value to continue the loop 

                        } 

                    } while (paymentChoice < 1 || paymentChoice > 2); 

  

                    if (paymentChoice == 1) { 

                        // Pay by cash 

                        Cash cashPayment = new Cash(); 

                        cashPayment.checkout(customer); 

                    } else if (paymentChoice == 2) { 

                        // Pay by credit 

                        System.out.print("Enter cardholder name: "); 

                        String cardholderName = input.next(); 

                        System.out.print("Enter card expiration date: "); 

                        String expirationDate = input.next(); 

                        System.out.print("Enter credit card number: "); 

                        String creditCardNumber = input.next(); 

                        try{ 

                        Credit creditPayment = new Credit(cardholderName, expirationDate, creditCardNumber); 

                        creditPayment.checkout(customer);} catch(IllegalArgumentException e){ 

                            System.out.println(e.getMessage()); 

                            break; 

                        } 

                    } else { 

                        System.out.println("Invalid payment choice. Returning to the customer menu."); 

                        break; 

                    } 

  

                    System.out.println("Thank you for your purchase!"); 

                    break; 

                case 8: 

                    System.out.println("Exit customer menu"); 

                    break; 

                default: 

                    System.out.println("Invalid choice. Please try again."); 

                    break; 

            } 

        } catch (InputMismatchException e) { 

            System.out.println("Invalid input. Please enter a number."); 

            input.nextLine(); // Clear the invalid input 

            choice = -1; // Set to an invalid value to continue the loop 

        } 

    } while (choice != 8); 

} 

  

static void employeeSystem() { 

    int empchoice; 

 

    do { 

        Menu.displayEmployeeMenu(); 

 

        try { 

            empchoice = input.nextInt(); 

            input.nextLine(); 

 

            switch (empchoice) { 

                case 1: 

                    // Add employee 

                    System.out.print("Enter employee's name: "); 

                    String name = input.next(); 

                    System.out.print("Enter employee's id: "); 

                    String id = input.next(); 

                    System.out.print("Enter employee's age: "); 

                    int age = input.nextInt(); 

                    System.out.print("Enter employee's contact number: "); 

                    String contactNum = input.next(); 

                    new Employee(name, id, age, contactNum); 

                    break; 

                case 2: 

                    // Update employee 

                    System.out.print("Enter employee's name: "); 

                    name = input.next(); 

                    System.out.print("Enter employee's id: "); 

                    id = input.next(); 

                    System.out.print("Enter employee's age: "); 

                    age = input.nextInt(); 

                    System.out.print("Enter employee's contact number: "); 

                    contactNum = input.next(); 

                    Employee.updateEmp(name, id, age, contactNum); 

                    break; 

                case 3: 

                    // Delete employee 

                    System.out.print("Enter employee's id: "); 

                    id = input.next(); 

                    Employee.deleteEmp(id); 

                    break; 

                case 4: 

                    // Add makeup product 

                    System.out.print("Enter makeup name: "); 

                    name = input.next(); 

                    System.out.print("Enter makeup id: "); 

                    id = input.next(); 

                    System.out.print("Enter makeup stock: "); 

                    int stock = input.nextInt(); 

                    System.out.print("Enter number of makeup shade (1. LIGHT 2. MEDIUM 3. DARK): "); 

                    int choiceInfo = input.nextInt(); 

 

                    Makeup.MakeupShade shade; 

                    if (choiceInfo == 1) { 

                        shade = Makeup.MakeupShade.LIGHT; 

                    } else if (choiceInfo == 2) { 

                        shade = Makeup.MakeupShade.MEDIUM; 

                    } else { 

                        shade = Makeup.MakeupShade.DARK; 

                    } 

 

                    System.out.print("Enter makeup price: "); 

                    double price = input.nextDouble(); 

                    new Makeup(name, id, price, stock, shade); 

                    System.out.println("Makeup product added."); 

                    break; 

                case 5: 

                    // Update item price 

                    System.out.print("Enter item's ID: "); 

                    id = input.next(); 

                    System.out.print("Enter item's new price: "); 

                    price = input.nextDouble(); 

                    Employee.updateItemPrice(id, price); 

                    break; 

                case 6: 

                    // Delete item 

                    System.out.print("Enter item's id to delete: "); 

                    id = input.next(); 

                    Employee.deleteItem(id); 

                    break; 

                case 7: 

                    // Add stock to item 

                    System.out.print("Enter the id of the item to add stock: "); 

                    id = input.next(); 

                    System.out.print("Enter the quantity you want to add: "); 

                    int quantity = input.nextInt(); 

                    Employee.addStock(id, quantity); 

                    break; 

                case 8: 

                    // Display all products 

                    Product.displayAllProducts(); 

                    break; 

                case 9: 

                    // Display all employees 

                    Employee.printEmp(); 

                    break; 

                case 10: 

                    System.out.println("Exiting employee menu"); 

                    break; 

                default: 

                    System.out.println("Invalid choice. Please try again."); 

                    break; 

            } 

        } catch (InputMismatchException e) { 

            System.out.println("Invalid input. Please enter a number."); 

            input.nextLine(); // Clear the invalid input 

            empchoice = -1; // Set to an invalid value to continue the loop 

        } 

    } while (empchoice != 10); 

} 

} 