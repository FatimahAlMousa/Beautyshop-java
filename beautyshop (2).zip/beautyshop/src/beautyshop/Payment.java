/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beautyshop;
import java.util.*;


public class Payment {
 private static final double TAX = 15; 

    private double totalprice; 

 

    public double taxes() { 

        double taxAmount = (totalprice * TAX) / 100; 

        return taxAmount ; 

    } 

 

    public double calculateTotalPrice(ArrayList<Product> clientOrder) { 

        totalprice=0; 

        if (!clientOrder.isEmpty()) { 

        for (Product product : clientOrder) { 

            totalprice += product.getPrice(); 

        } 

        } 

        return totalprice; 

    } 

     

    //Total bill method's implemention 

    public  double totalBill() { 

        calculateTotalPrice(Cart.clientOrder); 

        System.out.println("Sub-total: " + totalprice); 

        System.out.println("Taxes: " + taxes()); 

        System.out.println("Discount: " + discount()); 

        double totalbill=(totalprice + taxes() - discount()); 

        return totalbill; 

    } 

     

    public double discount() { 

        if (totalprice > 100) { 

            return (totalprice * 0.10); 

              

        } 

        else { 

            return 0; 

        } 

    } 

 

    public boolean completeOrder(Customer customer, ArrayList<Product> clientOrder) { 

        if (Cart.canDeliver(customer)) { 

            // Decrement stock and update customer information 

            Cart.decrementStock(); 

            customer.incrementNumOfOrder(); 

            return true; 

        }  

        else { 

            System.out.println("Delivery not available to the specified address."); 

            return false; 

        } 

    } 

} 
